#ifndef JSON_TESTSUITE_NUMBER_TO_STRING__GET_LEN_SIZE_H
#define JSON_TESTSUITE_NUMBER_TO_STRING__GET_LEN_SIZE_H

#include "../BaseTest.h"

class testNumberToString__getLenSize : public BaseTest {
public:
	testNumberToString__getLenSize(const std::string & name) : BaseTest(name){}
	void testStruct(void);
};

#endif
