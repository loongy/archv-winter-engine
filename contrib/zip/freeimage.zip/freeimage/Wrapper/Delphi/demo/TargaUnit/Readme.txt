TargaImage.pas is a TGraphic descendant for Delphi. Installing it
will allow Delphi TImage and TDBImage components to read Targa files
just like BMP & WMF files with no coding on your part.

It also adds the TGA file type to the Delphi Open/Save Picture dialog
boxes.

To install this unit, place it in your one of your library folders
and make it available to all your Delphi projects by using
Component>Install Component from the Delphi menus.

NOTE: any Delphi applications using this *must* have FreeImage.dll
installed in your application's folder, or somewhere in the path.

-----------------------

Tommy
Edinburgh, Scotland
LeTene@battlefieldeurope.org



